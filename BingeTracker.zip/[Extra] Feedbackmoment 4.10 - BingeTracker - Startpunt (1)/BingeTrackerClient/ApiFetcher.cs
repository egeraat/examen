﻿using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace BingeTrackerClient
{
    /// <summary>
    /// Fetches data from the API
    /// </summary>
    public static class ApiFetcher
    {
        const string API_URL = "http://localhost:8080";

        /// <summary>
        /// Fetches data from the API using the GET-method
        /// </summary>
        public static async Task<string> FetchData(string url)
        {
            var client = new HttpClient();
            client.BaseAddress = new Uri(API_URL);
            var response = await client.GetAsync(url);
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadAsStringAsync();
            }
            else
            {
                var error = await response.Content.ReadAsStringAsync();
                throw new Exception($"API error on GET {url}: {error}");
            }
        }

        /// <summary>
        /// Sends JSON data to the API with the PUT-method, for example to edit a genre
        /// </summary>
        public static async Task EditData(string url, string data)
        {
            var client = new HttpClient();
            client.BaseAddress = new Uri(API_URL);
            var content = new StringContent(data, Encoding.UTF8, "application/json");
            var response = await client.PutAsync(url, content);
            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync();
                throw new Exception($"API error on PUT {url}: {error}");
            }
        }

        /// <summary>
        /// Sends JSON data to the API with the POST-method, for example to add a new item
        /// </summary>
        public static async Task PostData(string url, string data)
        {
            var client = new HttpClient();
            client.BaseAddress = new Uri(API_URL);
            var content = new StringContent(data, Encoding.UTF8, "application/json");
            var response = await client.PostAsync(url, content);
            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync();
                throw new Exception($"API error on POST {url}: {error}");
            }
        }

        /// <summary>
        /// Deletes data from the API using the DELETE-method
        /// </summary>
        public static async Task DeleteData(string url)
        {
            var client = new HttpClient();
            client.BaseAddress = new Uri(API_URL);
            var response = await client.DeleteAsync(url);
            if (!response.IsSuccessStatusCode)
            {
                var error = await response.Content.ReadAsStringAsync();
                throw new Exception($"API error on DELETE {url}: {error}");
            }
        }
    }
}