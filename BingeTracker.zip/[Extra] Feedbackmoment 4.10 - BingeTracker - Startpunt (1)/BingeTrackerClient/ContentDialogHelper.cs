﻿using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BingeTrackerClient
{
    static class ContentDialogHelper
    {
        public static async Task AlertAsync(XamlRoot xamlRoot, string title, string content)
        {
            ContentDialog dialog = new ContentDialog()
            {
                Title = title,
                Content = content,
                CloseButtonText = "Ok",
                XamlRoot = xamlRoot
            };

            await dialog.ShowAsync();
        }
    }
}
