﻿using System.ComponentModel;

namespace BingeTrackerClient.Pages
{
    public class GenreCheckItem : INotifyPropertyChanged
    {
        public int Id { get; }
        public string Name { get; }

        private bool _isSelected;
        public bool IsSelected
        {
            get => _isSelected;
            set
            {
                _isSelected = value;
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(IsSelected)));
            }
        }

        public GenreCheckItem(int id, string name) { Id = id; Name = name; }
        public event PropertyChangedEventHandler? PropertyChanged;
    }
}