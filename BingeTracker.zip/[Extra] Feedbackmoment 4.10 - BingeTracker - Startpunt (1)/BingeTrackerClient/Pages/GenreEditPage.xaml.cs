using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;
using System.Text.Json;
using BingeTrackerShared;

namespace BingeTrackerClient.Pages
{
    public sealed partial class GenreEditPage : Page
    {
        public GenreEditPage()
        {
            this.InitializeComponent();
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            var genreId = (int)e.Parameter;
            deleteButton.Visibility = genreId == 0 ? Visibility.Collapsed : Visibility.Visible;
            if (genreId != 0) LoadGenre(genreId);
        }

        private async void LoadGenre(int genreId)
        {
            var genreJson = await ApiFetcher.FetchData($"/genre?id={genreId}");
            var genre = JsonSerializer.Deserialize<Genre>(genreJson);

            genreIdTextBox.Text = genre.Id.ToString();
            genreNameTextBox.Text = genre.Name;
        }

        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.GoBack();
        }

        private async void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            var genre = new Genre
            {
                Id = int.TryParse(genreIdTextBox.Text, out var id) ? id : 0,
                Name = genreNameTextBox.Text
            };
            var json = JsonSerializer.Serialize(genre);

            if (genre.Id == 0)
                await ApiFetcher.PostData("/genre", json);
            else
                await ApiFetcher.EditData("/genre", json);

            Frame.GoBack();
        }

        private async void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            var genreId = int.Parse(genreIdTextBox.Text);

            await ApiFetcher.DeleteData("/genre?id=" + genreId);

            this.Frame.GoBack();
        }
    }
}
