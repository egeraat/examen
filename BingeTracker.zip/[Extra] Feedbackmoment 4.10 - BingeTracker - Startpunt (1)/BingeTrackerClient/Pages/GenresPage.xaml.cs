using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;
using System.Text.Json;
using BingeTrackerShared;
using System.Net.Http;
namespace BingeTrackerClient.Pages
{
    public sealed partial class GenresPage : Page
    {
        public GenresPage()
        {
            this.InitializeComponent();

            loadingProgressRing.Visibility = Visibility.Visible;
            LoadGenres();
        }
        private async void LoadGenres()
        {
            try
            {
                var genresJson = await ApiFetcher.FetchData("/genres");
                var genres = JsonSerializer.Deserialize<List<Genre>>(genresJson);

                genresListView.ItemsSource = genres;
            } 
            catch (HttpRequestException)
            {
                await ContentDialogHelper.AlertAsync(
                    this.XamlRoot,
                    "Error connecting to the API",
                    "Please check your internet connection and try again."
                );
            }
            finally
            {
                loadingProgressRing.Visibility = Visibility.Collapsed;
            }
        }

        private void AddButton_Click(object sender, RoutedEventArgs e)
        => Frame.Navigate(typeof(GenreEditPage), 0);

        private void GoBackButton_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.GoBack();
        }

        private void GenresListView_ItemClick(object sender, ItemClickEventArgs e)
        {
            var genre = (Genre)e.ClickedItem;
            this.Frame.Navigate(typeof(GenreEditPage), genre.Id);
        }
    }
}
