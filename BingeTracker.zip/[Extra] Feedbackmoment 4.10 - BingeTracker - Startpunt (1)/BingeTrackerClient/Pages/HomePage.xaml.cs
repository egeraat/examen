using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;

namespace BingeTrackerClient.Pages
{
    public sealed partial class HomePage : Page
    {
        public HomePage() { this.InitializeComponent(); }

        private void ViewMoviesButton_Click(object sender, RoutedEventArgs e)
            => Frame.Navigate(typeof(MoviesPage));

        private void ViewSeriesButton_Click(object sender, RoutedEventArgs e)
            => Frame.Navigate(typeof(SeriesPage));

        private void ViewGenresButton_Click(object sender, RoutedEventArgs e)
            => Frame.Navigate(typeof(GenresPage));
    }
}