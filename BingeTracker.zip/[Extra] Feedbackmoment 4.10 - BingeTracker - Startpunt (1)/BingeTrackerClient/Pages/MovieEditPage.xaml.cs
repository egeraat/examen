using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using BingeTrackerShared;
using System.Text.Json;

namespace BingeTrackerClient.Pages
{
    public sealed partial class MovieEditPage : Page
    {
        private int _movieId;
        private List<GenreCheckItem> _genreItems = new();

        public MovieEditPage() { this.InitializeComponent(); }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            _movieId = (int)e.Parameter;
            deleteButton.Visibility = _movieId == 0 ? Visibility.Collapsed : Visibility.Visible;
            LoadData();
        }

        private async void LoadData()
        {
            var genresJson = await ApiFetcher.FetchData("/genres");
            var allGenres = JsonSerializer.Deserialize<List<Genre>>(genresJson)!;
            _genreItems = allGenres.Select(g => new GenreCheckItem(g.Id, g.Name)).ToList();

            if (_movieId != 0)
            {
                var movieJson = await ApiFetcher.FetchData($"/movie?id={_movieId}");
                var movie = JsonSerializer.Deserialize<Movie>(movieJson)!;

                titleTextBox.Text = movie.Title;
                platformTextBox.Text = movie.Platform ?? "";
                releaseYearBox.Value = movie.ReleaseYear;
                ratingControl.Value = movie.Rating;

                var selectedIds = movie.MovieGenres?.Select(mg => mg.GenreId).ToHashSet() ?? new();
                foreach (var item in _genreItems)
                    item.IsSelected = selectedIds.Contains(item.Id);
            }
            else
            {
                releaseYearBox.Value = DateTime.Now.Year;
                ratingControl.Value = 3;
            }

            genresCheckList.ItemsSource = _genreItems;
        }

        private void GoBackButton_Click(object sender, RoutedEventArgs e) => Frame.GoBack();

        private async void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            var movie = new Movie
            {
                Id = _movieId,
                Title = titleTextBox.Text,
                Platform = platformTextBox.Text,
                ReleaseYear = (int)releaseYearBox.Value,
                Rating = (int)ratingControl.Value,
                GenreIds = _genreItems.Where(g => g.IsSelected).Select(g => g.Id).ToList()
            };

            var json = JsonSerializer.Serialize(movie);

            if (_movieId == 0)
                await ApiFetcher.PostData("/movie", json);
            else
                await ApiFetcher.EditData("/movie", json);

            Frame.GoBack();
        }

        private async void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            await ApiFetcher.DeleteData($"/movie?id={_movieId}");
            Frame.GoBack();
        }
    }
}
