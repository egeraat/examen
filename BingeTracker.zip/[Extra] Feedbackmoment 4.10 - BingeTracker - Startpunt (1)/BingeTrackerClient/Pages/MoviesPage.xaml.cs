using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;

// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

using BingeTrackerShared;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Navigation;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;

namespace BingeTrackerClient.Pages
{
    public sealed partial class MoviesPage : Page
    {
        private List<Movie> _allMovies = new();

        public MoviesPage()
        {
            this.InitializeComponent();
            LoadData();
        }

        private async void LoadData()
        {
            loadingProgressRing.Visibility = Visibility.Visible;
            try
            {
                var genresJson = await ApiFetcher.FetchData("/genres");
                var genres = JsonSerializer.Deserialize<List<Genre>>(genresJson);

                genreFilterComboBox.Items.Clear();
                genreFilterComboBox.Items.Add(new ComboBoxItem { Content = "All genres", Tag = 0 });
                foreach (var g in genres)
                    genreFilterComboBox.Items.Add(new ComboBoxItem { Content = g.Name, Tag = g.Id });
                genreFilterComboBox.SelectedIndex = 0;

                var moviesJson = await ApiFetcher.FetchData("/movies");
                _allMovies = JsonSerializer.Deserialize<List<Movie>>(moviesJson)!;
                ApplyFilter();
            }
            catch (HttpRequestException)
            {
                await ContentDialogHelper.AlertAsync(XamlRoot, "Connection error",
                    "Could not reach the API. Is the server running?");
            }
            finally
            {
                loadingProgressRing.Visibility = Visibility.Collapsed;
            }
        }

        private void ApplyFilter()
        {
            if (genreFilterComboBox == null || sortComboBox == null || searchBox == null) return;
            if (genreFilterComboBox.SelectedItem == null) return;
            if (_allMovies == null) return;

            var search = searchBox.Text?.ToLower() ?? "";
            var sortTag = (sortComboBox.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "TitleAsc";
            var genreId = (int)((genreFilterComboBox.SelectedItem as ComboBoxItem)?.Tag ?? 0);

            var filtered = _allMovies
                .Where(m => m.Title.ToLower().Contains(search))
                .Where(m => genreId == 0 || (m.MovieGenres != null && m.MovieGenres.Any(mg => mg.GenreId == genreId)));

            filtered = sortTag switch
            {
                "TitleDesc" => filtered.OrderByDescending(m => m.Title),
                "YearDesc" => filtered.OrderByDescending(m => m.ReleaseYear),
                "YearAsc" => filtered.OrderBy(m => m.ReleaseYear),
                "RatingDesc" => filtered.OrderByDescending(m => m.Rating),
                "RatingAsc" => filtered.OrderBy(m => m.Rating),
                _ => filtered.OrderBy(m => m.Title)
            };

            moviesListView.ItemsSource = filtered.ToList();
        }

        private void Filter_Changed(object sender, object e) => ApplyFilter();

        private void GoBackButton_Click(object sender, RoutedEventArgs e) => Frame.GoBack();

        private void AddButton_Click(object sender, RoutedEventArgs e)
            => Frame.Navigate(typeof(MovieEditPage), 0);

        private void MoviesListView_ItemClick(object sender, ItemClickEventArgs e)
            => Frame.Navigate(typeof(MovieEditPage), ((Movie)e.ClickedItem).Id);
    }
}
