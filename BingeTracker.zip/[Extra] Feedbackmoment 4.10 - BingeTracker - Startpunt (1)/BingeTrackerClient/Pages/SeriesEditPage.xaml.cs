using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Controls.Primitives;
using Microsoft.UI.Xaml.Data;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Navigation;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;

// To learn more about WinUI, the WinUI project structure,
// and more about our project templates, see: http://aka.ms/winui-project-info.

using BingeTrackerShared;
using System.Text.Json;

namespace BingeTrackerClient.Pages
{
    public sealed partial class SeriesEditPage : Page
    {
        private int _seriesId;
        private List<GenreCheckItem> _genreItems = new();

        public SeriesEditPage() { this.InitializeComponent(); }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            _seriesId = (int)e.Parameter;
            deleteButton.Visibility = _seriesId == 0 ? Visibility.Collapsed : Visibility.Visible;
            LoadData();
        }

        private async void LoadData()
        {
            var genresJson = await ApiFetcher.FetchData("/genres");
            var allGenres = JsonSerializer.Deserialize<List<Genre>>(genresJson)!;
            _genreItems = allGenres.Select(g => new GenreCheckItem(g.Id, g.Name)).ToList();

            if (_seriesId != 0)
            {
                var seriesJson = await ApiFetcher.FetchData($"/series?id={_seriesId}");
                var series = JsonSerializer.Deserialize<Series>(seriesJson)!;

                titleTextBox.Text = series.Title;
                platformTextBox.Text = series.Platform ?? "";
                releaseYearBox.Value = series.ReleaseYear;
                seasonsBox.Value = series.Seasons;
                ratingControl.Value = series.Rating;

                var selectedIds = series.SeriesGenres?.Select(sg => sg.GenreId).ToHashSet() ?? new();
                foreach (var item in _genreItems)
                    item.IsSelected = selectedIds.Contains(item.Id);
            }
            else
            {
                releaseYearBox.Value = DateTime.Now.Year;
                seasonsBox.Value = 1;
                ratingControl.Value = 3;
            }

            genresCheckList.ItemsSource = _genreItems;
        }

        private void GoBackButton_Click(object sender, RoutedEventArgs e) => Frame.GoBack();

        private async void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            var series = new Series
            {
                Id = _seriesId,
                Title = titleTextBox.Text,
                Platform = platformTextBox.Text,
                ReleaseYear = (int)releaseYearBox.Value,
                Seasons = (int)seasonsBox.Value,
                Rating = (int)ratingControl.Value,
                GenreIds = _genreItems.Where(g => g.IsSelected).Select(g => g.Id).ToList()
            };

            var json = JsonSerializer.Serialize(series);

            if (_seriesId == 0)
                await ApiFetcher.PostData("/series", json);
            else
                await ApiFetcher.EditData("/series", json);

            Frame.GoBack();
        }

        private async void DeleteButton_Click(object sender, RoutedEventArgs e)
        {
            await ApiFetcher.DeleteData($"/series?id={_seriesId}");
            Frame.GoBack();
        }
    }
}
