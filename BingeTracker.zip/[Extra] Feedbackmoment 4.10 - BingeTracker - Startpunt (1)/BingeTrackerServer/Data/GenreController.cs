﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace BingeTrackerServer.Data
{
    class GenreController
    {
        internal static string GetAllJson()
        {
            using var db = new AppDbContext();

            var genres = db.Genres.ToList();
            var json = JsonSerializer.Serialize(genres);

            return json;
        }
        internal static bool TryAdd(string name)
        {
            using var db = new AppDbContext();
            var genre = new BingeTrackerShared.Genre { Name = name };
            db.Genres.Add(genre);
            db.SaveChanges();
            return true;
        }

        internal static string? GetOneJson(int genreId)
        {
            using var db = new AppDbContext();

            var genre = db.Genres.FirstOrDefault(g => g.Id == genreId);

            if (genre == null)
            {
                return null;
            }

            var json = JsonSerializer.Serialize(genre);

            return json;
        }

        internal static bool TryEdit(int genreId, string name)
        {
            using var db = new AppDbContext();

            var genre = db.Genres.FirstOrDefault(g => g.Id == genreId);

            if (genre == null)
            {
                return false;
            }

            genre.Name = name;
            db.SaveChanges();

            return true;
        }

        internal static bool TryDelete(int genreId)
        {
            using var db = new AppDbContext();
            var genre = db.Genres.FirstOrDefault(g => g.Id == genreId);

            if (genre == null)
            {
                return false;
            }

            db.Genres.Remove(genre);
            db.SaveChanges();

            return true;
        }
    }
}
