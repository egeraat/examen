﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BingeTrackerShared;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace BingeTrackerServer.Data
{
    class MovieController
    {
        static readonly JsonSerializerOptions _opts = new()
        {
            ReferenceHandler = ReferenceHandler.IgnoreCycles
        };

        internal static string GetAllJson()
        {
            using var db = new AppDbContext();
            var movies = db.Movies
                .Include(m => m.MovieGenres).ThenInclude(mg => mg.Genre)
                .ToList();
            return JsonSerializer.Serialize(movies, _opts);
        }

        internal static string? GetOneJson(int id)
        {
            using var db = new AppDbContext();
            var movie = db.Movies
                .Include(m => m.MovieGenres).ThenInclude(mg => mg.Genre)
                .FirstOrDefault(m => m.Id == id);
            return movie == null ? null : JsonSerializer.Serialize(movie, _opts);
        }

        internal static bool TryAdd(Movie data)
        {
            using var db = new AppDbContext();
            var movie = new Movie
            {
                Title = data.Title,
                Platform = data.Platform,
                ReleaseYear = data.ReleaseYear,
                Rating = data.Rating
            };
            db.Movies.Add(movie);
            db.SaveChanges();

            foreach (var genreId in data.GenreIds)
                db.MovieGenres.Add(new MovieGenre { MovieId = movie.Id, GenreId = genreId });
            db.SaveChanges();
            return true;
        }

        internal static bool TryEdit(Movie data)
        {
            using var db = new AppDbContext();
            var movie = db.Movies
                .Include(m => m.MovieGenres)
                .FirstOrDefault(m => m.Id == data.Id);
            if (movie == null) return false;

            movie.Title = data.Title;
            movie.Platform = data.Platform;
            movie.ReleaseYear = data.ReleaseYear;
            movie.Rating = data.Rating;

            db.MovieGenres.RemoveRange(movie.MovieGenres);
            foreach (var genreId in data.GenreIds)
                db.MovieGenres.Add(new MovieGenre { MovieId = movie.Id, GenreId = genreId });

            db.SaveChanges();
            return true;
        }

        internal static bool TryDelete(int id)
        {
            using var db = new AppDbContext();
            var movie = db.Movies.Include(m => m.MovieGenres).FirstOrDefault(m => m.Id == id);
            if (movie == null) return false;
            db.MovieGenres.RemoveRange(movie.MovieGenres);
            db.Movies.Remove(movie);
            db.SaveChanges();
            return true;
        }
    }
}