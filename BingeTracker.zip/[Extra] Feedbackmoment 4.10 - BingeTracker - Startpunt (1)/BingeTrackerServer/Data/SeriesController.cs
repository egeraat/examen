﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BingeTrackerShared;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace BingeTrackerServer.Data
{
    class SeriesController
    {
        static readonly JsonSerializerOptions _opts = new()
        {
            ReferenceHandler = ReferenceHandler.IgnoreCycles
        };

        internal static string GetAllJson()
        {
            using var db = new AppDbContext();
            var series = db.Series
                .Include(s => s.SeriesGenres).ThenInclude(sg => sg.Genre)
                .ToList();
            return JsonSerializer.Serialize(series, _opts);
        }

        internal static string? GetOneJson(int id)
        {
            using var db = new AppDbContext();
            var series = db.Series
                .Include(s => s.SeriesGenres).ThenInclude(sg => sg.Genre)
                .FirstOrDefault(s => s.Id == id);
            return series == null ? null : JsonSerializer.Serialize(series, _opts);
        }

        internal static bool TryAdd(Series data)
        {
            using var db = new AppDbContext();
            var series = new Series
            {
                Title = data.Title,
                Platform = data.Platform,
                ReleaseYear = data.ReleaseYear,
                Seasons = data.Seasons,
                Rating = data.Rating
            };
            db.Series.Add(series);
            db.SaveChanges();

            foreach (var genreId in data.GenreIds)
                db.SeriesGenres.Add(new SeriesGenre { SeriesId = series.Id, GenreId = genreId });
            db.SaveChanges();
            return true;
        }

        internal static bool TryEdit(Series data)
        {
            using var db = new AppDbContext();
            var series = db.Series
                .Include(s => s.SeriesGenres)
                .FirstOrDefault(s => s.Id == data.Id);
            if (series == null) return false;

            series.Title = data.Title;
            series.Platform = data.Platform;
            series.ReleaseYear = data.ReleaseYear;
            series.Seasons = data.Seasons;
            series.Rating = data.Rating;

            db.SeriesGenres.RemoveRange(series.SeriesGenres);
            foreach (var genreId in data.GenreIds)
                db.SeriesGenres.Add(new SeriesGenre { SeriesId = series.Id, GenreId = genreId });

            db.SaveChanges();
            return true;
        }

        internal static bool TryDelete(int id)
        {
            using var db = new AppDbContext();
            var series = db.Series.Include(s => s.SeriesGenres).FirstOrDefault(s => s.Id == id);
            if (series == null) return false;
            db.SeriesGenres.RemoveRange(series.SeriesGenres);
            db.Series.Remove(series);
            db.SaveChanges();
            return true;
        }
    }
}