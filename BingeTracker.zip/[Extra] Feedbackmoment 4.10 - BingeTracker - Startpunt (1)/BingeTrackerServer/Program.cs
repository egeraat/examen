﻿using System;
using System.IO;
using System.Net;
using System.Text;
using System.Text.Json;
using BingeTrackerServer.Data;

namespace BingeTrackerServer
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string url = "http://localhost:8080/";
            HttpListener listener = new HttpListener();
            listener.Prefixes.Add(url);
            listener.Start();

            Console.WriteLine("Server running on " + url);

            using (var db = new Data.AppDbContext())
            {
                db.Database.EnsureCreated();
            }

            while (true)
            {
                var context = listener.GetContext();
                var request = context.Request;
                var response = context.Response;

                try
                {
                    string result = HandleRequest(request);
                    byte[] buffer = Encoding.UTF8.GetBytes(result);
                    response.StatusCode = 200;
                    response.OutputStream.Write(buffer, 0, buffer.Length);
                }
                catch (Exception ex)
                {
                    response.StatusCode = 500;
                    byte[] buffer = Encoding.UTF8.GetBytes("Server error: " + ex.Message);
                    response.OutputStream.Write(buffer, 0, buffer.Length);
                }
                finally
                {
                    response.OutputStream.Close();
                }
            }
        }

        static string HandleRequest(HttpListenerRequest request)
        {
            string path = request.Url.AbsolutePath.ToLower();

            if (path == "/genres" && request.HttpMethod == "GET")
                return GenreController.GetAllJson();

            if (path == "/genre" && request.HttpMethod == "GET")
            {
                int id = int.Parse(request.QueryString["id"]);
                var json = GenreController.GetOneJson(id);
                if (json == null) throw new Exception("Genre not found");
                return json;
            }

            if (path == "/genre" && request.HttpMethod == "POST")
            {
                using var reader = new StreamReader(request.InputStream);
                var body = reader.ReadToEnd();
                var genre = JsonSerializer.Deserialize<BingeTrackerShared.Genre>(body);
                GenreController.TryAdd(genre.Name);
                return "{\"status\":\"created\"}";
            }

            if (path == "/genre" && request.HttpMethod == "PUT")
            {
                using var reader = new StreamReader(request.InputStream);
                var body = reader.ReadToEnd();
                var genre = JsonSerializer.Deserialize<BingeTrackerShared.Genre>(body);
                bool success = GenreController.TryEdit(genre.Id, genre.Name);
                if (!success) throw new Exception("Edit failed");
                return "{\"status\":\"ok\"}";
            }

            if (path == "/genre" && request.HttpMethod == "DELETE")
            {
                int id = int.Parse(request.QueryString["id"]);
                bool success = GenreController.TryDelete(id);
                if (!success) throw new Exception("Delete failed");
                return "{\"status\":\"ok\"}";
            }

            if (path == "/movies" && request.HttpMethod == "GET")
                return MovieController.GetAllJson();

            if (path == "/movie" && request.HttpMethod == "GET")
            {
                int id = int.Parse(request.QueryString["id"]);
                var json = MovieController.GetOneJson(id);
                if (json == null) throw new Exception("Movie not found");
                return json;
            }

            if (path == "/movie" && request.HttpMethod == "POST")
            {
                using var reader = new StreamReader(request.InputStream);
                var body = reader.ReadToEnd();
                var movie = JsonSerializer.Deserialize<BingeTrackerShared.Movie>(body);
                MovieController.TryAdd(movie);
                return "{\"status\":\"created\"}";
            }

            if (path == "/movie" && request.HttpMethod == "PUT")
            {
                using var reader = new StreamReader(request.InputStream);
                var body = reader.ReadToEnd();
                var movie = JsonSerializer.Deserialize<BingeTrackerShared.Movie>(body);
                if (!MovieController.TryEdit(movie)) throw new Exception("Edit failed");
                return "{\"status\":\"ok\"}";
            }

            if (path == "/movie" && request.HttpMethod == "DELETE")
            {
                int id = int.Parse(request.QueryString["id"]);
                if (!MovieController.TryDelete(id)) throw new Exception("Delete failed");
                return "{\"status\":\"ok\"}";
            }

            if (path == "/serieslist" && request.HttpMethod == "GET")
                return SeriesController.GetAllJson();

            if (path == "/series" && request.HttpMethod == "GET")
            {
                int id = int.Parse(request.QueryString["id"]);
                var json = SeriesController.GetOneJson(id);
                if (json == null) throw new Exception("Series not found");
                return json;
            }

            if (path == "/series" && request.HttpMethod == "POST")
            {
                using var reader = new StreamReader(request.InputStream);
                var body = reader.ReadToEnd();
                var series = JsonSerializer.Deserialize<BingeTrackerShared.Series>(body);
                SeriesController.TryAdd(series);
                return "{\"status\":\"created\"}";
            }

            if (path == "/series" && request.HttpMethod == "PUT")
            {
                using var reader = new StreamReader(request.InputStream);
                var body = reader.ReadToEnd();
                var series = JsonSerializer.Deserialize<BingeTrackerShared.Series>(body);
                if (!SeriesController.TryEdit(series)) throw new Exception("Edit failed");
                return "{\"status\":\"ok\"}";
            }

            if (path == "/series" && request.HttpMethod == "DELETE")
            {
                int id = int.Parse(request.QueryString["id"]);
                if (!SeriesController.TryDelete(id)) throw new Exception("Delete failed");
                return "{\"status\":\"ok\"}";
            }

            throw new Exception("Endpoint not found");
        }
    }
}