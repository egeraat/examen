﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;

namespace BingeTrackerShared
{
    public class Movie
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Platform { get; set; }
        public int ReleaseYear { get; set; }
        public int Rating { get; set; }

        public List<MovieGenre> MovieGenres { get; set; } = new();

        [NotMapped]
        public List<int> GenreIds { get; set; } = new();
    }
}