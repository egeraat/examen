﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace BingeTrackerShared
{
    public class Series
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Platform { get; set; }
        public int ReleaseYear { get; set; }
        public int Seasons { get; set; }
        public int Rating { get; set; } 

        public List<SeriesGenre> SeriesGenres { get; set; } = new();

        [NotMapped]
        public List<int> GenreIds { get; set; } = new();
    }
}